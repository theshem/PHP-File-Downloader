<?php

define(pc_NAME,"Page Creator:");
define(pc_CONFIG,"Create a Page");
define(pc_EDIT,"Edit a Page");
define(pc_MENU,"Menu");
define(pc_README,"Readme");

?>