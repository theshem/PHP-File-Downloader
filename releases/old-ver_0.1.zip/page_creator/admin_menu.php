<?php
	$menutitle  = pc_NAME." ".pc_MENU;

	$butname[]  = "Create a Page";
	$butlink[]  = "admin_config.php";
	$butid[]	 = "config";
	
	$butname[]  = "Edit a Page";
	$butlink[]  = "admin_edit.php";
	$butid[]	 = "edit";

	$butname[]  = "Readme";
	$butlink[]  = "admin_readme.php";
	$butid[]	 = "readme";

	global $pageid;
	for ($i=0; $i<count($butname); $i++) {
		$var[$butid[$i]]['text'] = $butname[$i];
		$var[$butid[$i]]['link'] = $butlink[$i];
	};

	show_admin_menu($menutitle, $pageid, $var);

?>