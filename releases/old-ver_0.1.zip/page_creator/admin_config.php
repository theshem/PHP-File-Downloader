<?php
	require_once("../../class2.php");
	if(!getperms("P")) { echo "You do not have permission"; exit; }
	require_once(e_ADMIN."auth.php");
	include(e_PLUGIN."page_creator/language/".e_LANGUAGE.".php");
	
if($_POST['page_name'] != "") {
	if(!file_exists("../../".$_POST['page_name'].".php")) {
	
		$pageName = $_POST['page_name'];
		
		$createPage = fopen("../../".$pageName.".php", 'w') or die("Could not create the page!");
		
		$start = "<?php

// This IS the e107 CMS, this does make it all e107
require_once(\"class2.php\");

// Get the header, starting the e107 website layout (With menus and sitelinks.. etc..)
require_once(HEADERF);";
		
		if($_POST['allowed'] == "Members") {
			$allowed = "
		
// Only allow members to view page!		
if(!USER) {
	\$ns->tablerender('Opps!', 'You must login to view this page');
	require_once(FOOTERF);
	exit;
}";
		} elseif($_POST['allowed'] == "Admins") {
			$allowed = "

// Only allow admins to view page!
if(!ADMIN) {
	\$ns->tablerender('Opps!', 'You must login as a admin to view this page');
	require_once(FOOTERF);
	exit;
}";
		}
		$end = "';

// Show the page content and its title
\$ns->tablerender(\"".$pageName."\", \$page_content);

// Show the comments if enabled
echo \$comments_unique;

// Then include the footer to end the page
require_once(FOOTERF);

?>";
		
		$allowed .= "

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// This is the page content
\$page_content = '
";
		
		$page_content_o = str_replace("'", "\"", $_POST['page_content']);
		$page_content_o = str_replace("\n", "\n<br />\n", $page_content_o);
		
		$extra = "";
	
		if($_POST['comment']) {
			$extra .= "
';
// This is the comment form, a simple way to add comments to a page!
global \$pref, \$e107cache, \$tp;

require_once(e_HANDLER.'comment_class.php');
require(e_FILE.'shortcode/batch/comment_shortcodes.php');
\$GLOBALS['comment_shortcodes'] = \$comment_shortcodes;

\$pid = 0;
\$cobj = new comment();

if (isset(\$_POST['commentsubmit'])) {
\$cobj->enter_comment(\$_POST['author_name'], \$_POST['comment'], ".$pageName.", 1, \$pid, \$_POST['subject']);
	if (\$pref['cachestatus']){
		\$e107cache->clear('comment.".$pageName.".{$sub_action}');
	}
}

\$query = \$pref['nested_comments'] ?
'comment_item_id=\"1\" AND comment_type=\"".$pageName."\" AND comment_pid=\"0\" ORDER BY comment_datestamp' :
'comment_item_id=\"1\" AND comment_type=\"".$pageName."\" ORDER BY comment_datestamp';

unset(\$comments_unique);
if (\$comment_total = \$sql->db_Select('comments', '*', \$query)) {
	\$width = 0;
	while (\$row = \$sql->db_Fetch()) {
		if (\$pref['nested_comments']) {
			\$comments_unique .= \$cobj->render_comment(\$row, '".$pageName."', 'comment', 1, \$width, \$subject, true);
		} else {
			\$comments_unique .= \$cobj->render_comment(\$row, '".$pageName."', 'comment', 1, \$width, \$subject, true);
		}
	}
	if (ADMIN && getperms('B')) {
		\$comments_unique .= '<div style=\"text-align:right\"><a href=\"'.e_ADMIN.'modcomment.php?".$pageName.".1\">'.LAN_314.'</a></div>';
	}
}

ob_start();
\$cobj->compose_comment('".$pageName."', 'comment', 1, \$width, \$subject, false);
\$comments_unique = ob_get_contents();
ob_end_clean();

\$misc = '";
		}
		
		fwrite($createPage, $start.$allowed .$page_content_o.$extra.$end);
		fclose($createPage);
		
		$message = 'Page Created';
	} else {
		$message = 'Page does already exist!';
	}
}

if(isset($message)) { $ns->tablerender("", "<div style='text-align: center'><b>".$message."</b></div>"); }

$config = "
<form method='post' action='".e_SELF."' id='cfgform'>
	<table width='90%' class='fborder'>
		<tr>
			<td width='50%' class='forumheader2'>
				Page Name:<br /><i>Both title of the page, and name of the file!</i>
			</td>
			<td width='50%' class='forumheader3'>
				<input class='tbox' type='text' name='page_name' size='25' maxlength='25' />
			</td>
		</tr>
		<tr>
			<td class='forumheader2' style='width: 50%;'>
				Who can access this page?
			</td>
			<td class='forumheader3' style='width: 50%;'>
				<select name='allowed' class='tbox'>
					<option value='Everyone' name='Everyone'>Everyone</option>
					<option value='Members' name='Members'>Members</option>
					<option value='Admins' name='Admins'>Admins</option>
				</select>
			</td>
		</tr>
		<tr>
			<td colspan='2' class='forumheader3'>
				<textarea name='page_content' cols='175' rows='30' class='tbox'></textarea>
			</td>
		</tr>
		<tr>
			<td width='50%' class='forumheader2'>
				Enable Comments?
			</td>
			<td width='50%' class='forumheader3'>
				<input class='tbox' type='checkbox' name='comment' />
			</td>
		</tr>
		<tr>
			<td colspan='2' class='forumheader' style='text-align: center;'>
				<input class='button' type='submit' value='Create the Page' />
			</td>
		</tr>
	</table>
</form>";
	
	$ns->tablerender(pc_NAME." ".pc_CONFIG, $config);
	require_once(e_ADMIN."footer.php");
?>