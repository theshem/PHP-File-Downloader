<?php
require_once("../../class2.php");
if(!getperms("P")) { echo "You do not have permission"; exit; }
require_once(e_ADMIN."auth.php");
include(e_PLUGIN."page_creator/language/".e_LANGUAGE.".php");

if(isset($_POST['open_page'])) {
	if(file_exists("../../".$_POST['page_to_edit'].".php")) {
		$page_edit = fopen("../../".$_POST['page_to_edit'].".php", 'r');
		$page_edit_o = fread($page_edit, filesize("../../".$_POST['page_to_edit'].".php"));
		$page_edit_o = str_replace("'", "\"", $page_edit_o);
		if(strpos($page_edit_o, 'e107 website system')) {
			$message = "I have to stop you there, this is a e107 core file and should never been involved in a plugin like this! ";
			$ns->tablerender(pc_NAME." ".pc_EDIT, $message);
			require_once(e_ADMIN."footer.php");
			exit;
		}
		if(strpos($page_edit_o, '!USER')) {
			if(strpos($page_edit_o, 'comment_class')) {
				$page_edit_os = substr($page_edit_o, 490, -1681);
			} else {
				$page_edit_os = substr($page_edit_o, 490, -223);
			}
		}
		elseif(strpos($page_edit_o, '!ADMIN')) {
			if(strpos($page_edit_o, 'comment_class')) {
				$page_edit_os = substr($page_edit_o, 497, -1681);
			} else {
				$page_edit_os = substr($page_edit_o, 497, -223);
			}
		}
		elseif(strpos($page_edit_o, 'comment_class')) {
			$page_edit_os = substr($page_edit_o, 333, -1681);
		}
		else {
			$page_edit_os = substr($page_edit_o, 333, -223);
		}
		$message = "Page can now be edited";
	} else {
		$message = "Page does not exist";
	}
	if($_POST['page_to_edit'] == "") {
		$message = "Its a good idea to write in the FileName";
	}
}

if(isset($_POST['save_changes'])) {
	if($_POST['page_content'] != "") {
		$page_content = str_replace("\'", "\"", $_POST['page_content']);
		$message = "
			Are you sure you want to edit the file? This is permanent, and can NEVER be reversed!
			<form method='post' action='".e_SELF."'>
				<input type='hidden' name='page_name' value='".$_POST['page_name']."' />
				<input type='hidden' name='page_content' value='".$page_content."' />
				<input type='submit' class='tbox' name='confirm_edit_page' value='Yes' />
				<input type='submit' class='tbox' name='cancel' value='No' />
			</form>";
	} else {
		$message = "It's never a good idea to completely remove a pages content (Editing of Page was canceled)";
	}
}

if(isset($_POST['confirm_edit_page'])) {
	$page_edit = fopen("../../".$_POST['page_name'].".php", 'r');
	$page_edit_o = fread($page_edit, filesize("../../".$_POST['page_name'].".php"));
	
	if(strpos($page_edit_o, '!USER')) {
		if(strpos($page_edit_o, 'comment_class')) {
			$page_edit_os = substr($page_edit_o, 490, -1681);
		} else {
			$page_edit_os = substr($page_edit_o, 490, -223);
		}
	}
	elseif(strpos($page_edit_o, '!ADMIN')) {
		if(strpos($page_edit_o, 'comment_class')) {
			$page_edit_os = substr($page_edit_o, 497, -1681);
		} else {
			$page_edit_os = substr($page_edit_o, 497, -223);
		}
	}
	elseif(strpos($page_edit_o, 'comment_class')) {
		$page_edit_os = substr($page_edit_o, 333, -1681);
	}
	else {
		$page_edit_os = substr($page_edit_o, 333, -223);
	}
	
	$str_page_write = str_replace($page_edit_os, $_POST['page_content'], $page_edit_o);
	
	$page_edit_now = fopen("../../".$_POST['page_name'].".php", 'w');
	fwrite($page_edit_now, $str_page_write);
	fclose($page_edit_now);
	$message = "Page was edited without any problems!";
}

if(isset($_POST['cancel'])) {
	$message = "Sometimes it's a good idea to leave it all as it is!";
}

if(isset($message)) { $ns->tablerender("", "<div style='text-align: center'><b>".$message."</b></div>"); }

$config = "
<table width='90%' class='fborder'>
	<tr>
		<td class='forumheader2'>
			Select a Page to edit:<br /><i>Example: \"test\"<br />You do not need any .php ending or something similar.</i>
		</td>
		<td class='forumheader3'>
			<form method='post' action='".e_SELF."'>
				<input type='text' class='tbox' size='25' maxlength='25' name='page_to_edit' />
				<input class='button' type='submit' name='open_page' value='Open Page' />
			</form>
		</td>
	</tr>
	<tr>
		<td colspan='2' class='forumheader3'>
			<form method='post' action='".e_SELF."'>
				<input type='hidden' value='".$_POST['page_to_edit']."' name='page_name' />
				<textarea name='page_content' cols='175' rows='30' class='tbox'>".$page_edit_os."</textarea>
				<br />
				<div style='text-align: center'>
					<input class='button' name='save_changes' type='submit' value='Save Changes' />
				</div>
			</form>
		</td>
	</tr>
</table>";
	
	$ns->tablerender(pc_NAME." ".pc_EDIT, $config);
	require_once(e_ADMIN."footer.php");
?>