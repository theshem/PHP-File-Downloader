<?php

$eplug_name = "Page Creator (For Noobs)";
$eplug_version = "1.1";

$eplug_author = "eleljrk";
$eplug_url = "http://jurksplanet.co.cc";
$eplug_folder = "page_creator";
$eplug_email = "eleljrk@gmail.com";
$eplug_description = "This plugin can create pages like my_page.php in a easy way from your Admin Panel!";
$eplug_compatible = "e107: 0.7.xx (Tested version: 0.7.16)";
$eplug_readme = "admin_readme.php";
$eplug_compliant = TRUE;
$eplug_status = TRUE;

$eplug_done = "The Page Creator has been installed!";
$eplug_upgrade_done = "The Page Creator has been upgraded!";

$eplug_icon = $eplug_folder."/images/icon32.png";
$eplug_icon_small = $eplug_folder."/images/icon16.png";
$eplug_caption = "Configure the Page Creator";
$eplug_conffile = "admin_config.php";

$eplug_link = FALSE;
$eplug_link_name = "";
$eplug_link_url = "";
$eplug_link_perms = "";
	
$eplug_prefs = array(
);
?>