<?php

if (!defined('e107_INIT')) { exit; }

require_once("".e_PLUGIN."archive_menu/archive_class.php");	
$RSS_text = RSS_Links2(SITEURL."plugins/rss_menu/rss.php?news.2", 15);

$ns -> tablerender("خبرهای پیشین",  $RSS_text);

?>